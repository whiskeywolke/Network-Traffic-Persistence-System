/*
 * features.h
 *
 *  Created on: Nov 1, 2016
 *      Author: rvelea
 */

#ifndef SRC_TESTS_FEATURES_FEATURES_H_
#define SRC_TESTS_FEATURES_FEATURES_H_

#include <stdint.h>

typedef uint64_t feature_type_t;

#endif /* SRC_TESTS_FEATURES_FEATURES_H_ */
