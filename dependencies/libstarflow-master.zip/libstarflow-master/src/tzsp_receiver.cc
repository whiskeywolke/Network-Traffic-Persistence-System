
#include "../include/starflow/tzsp_receiver.h"

starflow::tzsp_receiver::tzsp_receiver(const std::string& listen_addr_)
        : _socket(om::net::socket::type::dgram),
          _poll(_socket.fd(), std::bind(&tzsp_receiver::_poll_event, this, _1, _2))
{
    auto host_port = om::net::parse_host_port(listen_addr_);
    _socket.bind(host_port.first, host_port.second);
}

void starflow::tzsp_receiver::operator()(packet_handler_t&& packet_handler_)
{
    _packet_handler = packet_handler_;
    _poll.block();
}

void starflow::tzsp_receiver::_poll_event(int fd_, om::async::poll::event ev_)
{
    if (fd_ == _socket.fd() && (_rx_len = _socket.receive(_rx_buf, sizeof(_rx_buf)))) {

        _msg_end = _rx_buf + _rx_len;
        auto tzsp_hdr = (tzsp_header*) _rx_buf;
        std::size_t msg_offset = sizeof(struct tzsp_header);

        _msg_ptr = _rx_buf + msg_offset;

        if (tzsp_hdr->version == 1 && tzsp_hdr->type == 0) { // type 0: TZSP_TYPE_RECEIVED_TAG_LIST

            while (_msg_ptr < _msg_end) {
                auto tag = (struct tzsp_tag *) _rx_buf;

                if (tag->type == 1) { // tag end
                    msg_offset++;
                    _msg_ptr = _rx_buf + msg_offset;
                    break;
                } else if (tag->type == 0) { //tag padding
                    msg_offset++;
                    _msg_ptr = _rx_buf + msg_offset;
                } else {
                    if (_msg_ptr + sizeof(struct tzsp_tag) > _msg_end ||
                        _msg_ptr + sizeof(struct tzsp_tag) + tag->length > _msg_end)
                    {
                        break; // malformed packet - skip
                    }

                    msg_offset += sizeof(struct tzsp_tag) + tag->length;
                    _msg_ptr = _rx_buf + msg_offset;
                }
            }

            _packet_handler(_rx_buf + msg_offset, (std::size_t) _rx_len - msg_offset);
        }
    }
}
