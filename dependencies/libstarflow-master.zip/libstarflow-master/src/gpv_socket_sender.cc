
#include "../include/starflow/gpv_socket_sender.h"

starflow::gpv_socket_sender::gpv_socket_sender(const std::string& dest_)
    : _socket(om::net::socket::type::dgram)
{
    auto host_port = om::net::parse_host_port(dest_);
    _ip_dst = host_port.first;
    _udp_dst = host_port.second;
}

void starflow::gpv_socket_sender::send(const gpv_t& gpv_)
{
    unsigned gpv_byte_len = sizeof(gpv::hdr) + gpv_.hdr.pkt_count * sizeof(gpv::pkt);
    _socket.send_to(_ip_dst, _udp_dst, (const unsigned char*) &gpv_, gpv_byte_len);
}
