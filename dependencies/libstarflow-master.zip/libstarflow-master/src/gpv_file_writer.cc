
#include "../include/starflow/gpv_file_writer.h"

starflow::gpv_file_writer::gpv_file_writer(const std::string& file_name_)
        : _file_stream(file_name_, std::ios::binary | std::ios::out) { }

std::size_t starflow::gpv_file_writer::write(const gpv_t& gpv_)
{
    std::size_t bytes_written = sizeof(gpv::hdr);
    _stream.write((char*)&gpv_.hdr, sizeof(gpv::hdr));

    for (auto i = 0; i < gpv_.hdr.pkt_count; i++) {
        _stream.write((char*) &gpv_.pkt[i], sizeof(gpv::pkt));
        bytes_written += sizeof(gpv::pkt);
    }

    return bytes_written;
}
