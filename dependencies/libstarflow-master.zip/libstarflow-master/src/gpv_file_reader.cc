
#include "../include/starflow/gpv_file_reader.h"

starflow::gpv_file_reader::gpv_file_reader(const std::string& file_name_, bool use_buffer_)
    : _file_stream(file_name_, std::ios::binary | std::ios::in),
      _use_buffer(use_buffer_),
      _data()
{
    gpv_t gpv;

    if (_use_buffer) {
        while (!_eof()) {
            _read_gpv(gpv);
            _data.push_back(gpv);
        }
        _iter = std::begin(_data);
    }
}

bool starflow::gpv_file_reader::next(gpv_t& gpv_)
{
    if (_use_buffer)
        gpv_ = *(_iter++);
    else
        _read_gpv(gpv_);

    return !done();
}

void starflow::gpv_file_reader::reset()
{
    if (_use_buffer)
        _iter = std::begin(_data);
    else
        _reset();
}

bool starflow::gpv_file_reader::done()
{
    return _use_buffer ? _iter == _data.end() : _eof();
}

void starflow::gpv_file_reader::_read_gpv(gpv_t& gpv_)
{
    std::size_t pkts_read = 0;
    _stream.read((char*) &(gpv_.hdr), sizeof(gpv::hdr));

    for ( ; pkts_read < gpv_.hdr.pkt_count; pkts_read++)
        _stream.read((char*) &(gpv_.pkt[pkts_read]), sizeof(gpv::pkt));

    for ( ; pkts_read < gpv::MAX_LEN; pkts_read++)
        gpv_.pkt[pkts_read] = {};
}
