
#ifdef WITH_NETMAP

#include "../include/starflow/gpv_netmap_sender.h"

starflow::gpv_netmap_sender::gpv_netmap_sender(const std::string& iface_name_,
    const std::string& mac_src_, const std::string& ip_port_src_, const std::vector<std::string>& mac_dst_,
    const std::vector<std::string>& ip_port_dst_, unsigned verbosity_)
    : _iface(iface_name_),
      _ether(_header_buffer),
      _ip(_header_buffer + _ether.len()),
      _udp(_header_buffer + _ether.len() + _ip.len()),
      _verbosity(verbosity_)
{
    if (ip_port_dst_.empty() || mac_dst_.empty() || ip_port_dst_.size() != mac_dst_.size())
        throw std::invalid_argument("gpv_netmap_sender: invalid destination specification");

    om::net::mac_addr src_mac(mac_src_);
    auto src_ip_port_pair = om::net::parse_host_port(ip_port_src_);
    auto src_ip = om::net::ip4_addr::from_string(src_ip_port_pair.first);
    auto src_port = src_ip_port_pair.second;

    for (unsigned i = 0; i < ip_port_src_.size() && i < mac_dst_.size(); i++) {
        om::net::mac_addr dst_mac(mac_dst_[i]);
        auto dst_ip_port_pair = om::net::parse_host_port(ip_port_dst_[i]);
        auto dst_ip = om::net::ip4_addr::from_string(dst_ip_port_pair.first);
        auto dst_port = dst_ip_port_pair.second;
        _load_balancer.add_destination(dst_ip, dst_port, dst_mac);
    }

    _ether.set_src_addr(src_mac);
//    _ether.set_dest_addr(dst_mac);
    _ether.set_ether_type(0x0800);

    _ip.set_src_addr(src_ip);
//    _ip.set_dest_addr(dst_ip);
    _ip.set_proto(17);
    _ip.set_ttl(64);
    _ip.set_ip_hl(5);
    _ip.set_ip_v(4);

    _udp.set_src_port(src_port);
//    _udp.set_dest_port(dst_port);

    if (_verbosity > 0) {
        std::cout << "destinations: " << std::endl;
        for (unsigned i = 0; i < ip_port_src_.size() && i < mac_dst_.size(); i++)
            std::cout << "   " << mac_dst_[i] << " / " << ip_port_dst_[i] << std::endl;
    }
}

starflow::gpv_netmap_sender::gpv_netmap_sender(const std::string& iface_name_,
    const std::string& mac_src_, const std::string& ip_port_src_, const std::string& mac_dst_,
    const std::string& ip_port_dst_, unsigned verbosity_)
    : gpv_netmap_sender(iface_name_, mac_src_, ip_port_src_, std::vector<std::string>(1, mac_dst_),
            std::vector<std::string>(1, ip_port_dst_), verbosity_) { }

void starflow::gpv_netmap_sender::send(const gpv_t& gpv_)
{
    auto tx_ring = _iface.tx_rings[_next_ring()];
    auto *tx_buf = tx_ring.next_buf();

    //TODO: compute and set ethernet crc
    //TODO: total_bytes() miscalculates frame length: compute manually for now
    unsigned gpv_len = sizeof(gpv::hdr) + gpv_.hdr.pkt_count * sizeof(gpv::pkt);

    std::memcpy(tx_buf + 14 + 20 + 8, (char*)(&gpv_), gpv_len);

    auto dst = _load_balancer.destination(gpv::ipv4_5tuple::from_gpv(gpv_));
    _ether.set_dest_addr(dst.mac);
    _ip.set_dest_addr(dst.ip);
    _udp.set_dest_port(dst.port);

    _ip.set_total_len((uint16_t )(20 + 8 + gpv_len));
    _udp.set_payload_length((uint16_t )(gpv_len));
    std::memcpy(tx_buf, _header_buffer, 14 + 20 + 8);
    tx_ring.advance(14 + 20 + 8 + gpv_len);
    _packet_count++;
}

unsigned starflow::gpv_netmap_sender::_next_ring()
{
    for (unsigned i = 0; !_iface.tx_rings[_current_ring].avail(); i++) {
        _current_ring = (++_current_ring) % _iface.tx_rings.count();

        if (i % _iface.tx_rings.count() == 0)
            _iface.tx_rings.synchronize();
    }

    return _current_ring;
}

#endif
