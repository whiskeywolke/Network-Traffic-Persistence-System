
#include "../include/starflow/gpv_socket_receiver.h"

starflow::gpv_socket_receiver::gpv_socket_receiver(const std::string& addr_,
    gpv_handler_t&& gpv_handler_)
    : _gpv_handler(gpv_handler_),
      _socket(om::net::socket::type::dgram),
      _poll(_socket.fd(), std::bind(&gpv_socket_receiver::_poll_event, this, _1, _2))
{
    auto host_port = om::net::parse_host_port(addr_);
    _socket.bind(host_port.first, host_port.second);
}

void starflow::gpv_socket_receiver::operator()()
{
    _poll.block();
}

void starflow::gpv_socket_receiver::_poll_event(int fd_, om::async::poll::event ev_)
{
    if (fd_ == _socket.fd() && (_rx_len = _socket.receive(_rx_buf, sizeof(_rx_buf))))
        _gpv_handler(*((gpv_t*) _rx_buf));
}
