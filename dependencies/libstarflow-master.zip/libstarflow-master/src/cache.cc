
#include <chrono>
#include "../include/starflow/cache.h"
#include "../include/starflow/util.h"

#include <iostream>

#include <om/om.h>

unsigned long long starflow::cache::stats::pkt_count() const
{
    return _pkt_count;
}

unsigned long long starflow::cache::stats::gpv_count() const
{
    return _gpv_count;
}

unsigned long long starflow::cache::stats::new_slot_count() const
{
    return _new_slot_count;
}

unsigned long long starflow::cache::stats::append_count() const
{
    return _append_count;
}


unsigned long long starflow::cache::stats::collision_count() const
{
    return _collision_count;
}

double starflow::cache::stats::new_slot_ratio() const
{
    return (double) _new_slot_count / _pkt_count;
}

double starflow::cache::stats::append_ratio() const
{
    return (double) _append_count / _pkt_count;
}

double starflow::cache::stats::collision_ratio() const
{
    return (double) _collision_count / _pkt_count;
}

double starflow::cache::stats::mean_gpv_length() const
{
    return (double) _pkt_count / _gpv_count;
}

starflow::cache::cache(std::size_t p1_height_, std::size_t p1_width_, std::size_t p2_height_,
    std::size_t p2_width_, std::size_t associativity, gpv_handler_t&& gpv_handler_,
    bool collect_stats_)
    : _p1_height(p1_height_),
      _p1_width(p1_width_),
      _p2_height(p2_height_),
      _p2_width(p2_width_),
      _associativity(associativity),
      _gpv_handler(gpv_handler_),
      _collect_stats(collect_stats_),
      _stats(),
      _p1(new cache_slot[_p1_height]),
      _seed((unsigned) std::chrono::system_clock::now().time_since_epoch().count())
{ }

void starflow::cache::add_packet(const unsigned char* pkt_buffer_, unsigned long timestamp_us_,
    bool includes_eth_)
{
    auto key     = _packet_key(pkt_buffer_, includes_eth_);
    auto slot_id = util::hash::murmur3(&key, sizeof(key), _seed).h2 % _p1_height;
    auto& p1_slot = _p1[slot_id];

    auto offset = includes_eth_ ?  14 : 0;
    auto ip = om::net::ip4_header(pkt_buffer_ + offset);
    offset += ip.len();
    auto tcp = om::net::tcp_header(pkt_buffer_ + offset);
    auto udp = om::net::udp_header(pkt_buffer_ + offset);

    if (!p1_slot.used) { // new flow in empty slot

        if (_collect_stats) _stats._new_slot_count++;

        p1_slot.used = true;

        _set_gpv_hdr(p1_slot.gpv, key, timestamp_us_);
        auto& pkt              = p1_slot.gpv.pkt[0];
        pkt.pkt_len            = (unsigned) ip.total_len();
        pkt.ts_delta_us        = timestamp_us_ - p1_slot.gpv.hdr.ts_us;
        pkt.ts_egress_delta_us = 0;
        pkt.queue_id           = 0;
        pkt.queue_depth        = 0;
        pkt.ip_id              = ip.id();

        if (ip.proto() == 6) {
            pkt.pd = tcp.seq_no();
        } else {
            pkt.pd = 0;
        }

        if (p1_slot.gpv.hdr.pkt_count >= _p1_width) {
            _evict(p1_slot.gpv);
            p1_slot.used = false;
        }

    } else {
        if (_is_same_gpv(p1_slot.gpv, key)) { // append

            if (_collect_stats) _stats._append_count++;

            auto& pkt = p1_slot.gpv.pkt[p1_slot.gpv.hdr.pkt_count++];
            pkt.pkt_len            = (unsigned) ip.total_len();
            pkt.ts_delta_us        = timestamp_us_ - p1_slot.gpv.hdr.ts_us;
            pkt.ts_egress_delta_us = 0;
            pkt.queue_id           = 0;
            pkt.queue_depth        = 0;
            pkt.ip_id              = ip.id();

            if (ip.proto() == 6) {
                pkt.pd = tcp.seq_no();
            } else {
                pkt.pd = 0;
            }

            if (p1_slot.gpv.hdr.pkt_count >= _p1_width) {
               _evict(p1_slot.gpv);
               p1_slot.used = false;
            }

        } else { // collision

            if (_collect_stats) _stats._collision_count++;

            _evict(p1_slot.gpv);
            _set_gpv_hdr(p1_slot.gpv, key, timestamp_us_);
            auto &pkt = p1_slot.gpv.pkt[0];
            pkt.pkt_len            = (unsigned) ip.total_len();
            pkt.ts_delta_us        = timestamp_us_ - p1_slot.gpv.hdr.ts_us;
            pkt.ts_egress_delta_us = 0;
            pkt.queue_id           = 0;
            pkt.queue_depth        = 0;
            pkt.ip_id              = ip.id();

            if (ip.proto() == 6) {
                pkt.pd = tcp.seq_no();
            } else {
                pkt.pd = 0;
            }
        }
    }
}

void starflow::cache::flush()
{
    for (auto i = 0; i < _p1_height; i++)
        if (_p1[i].used)
            _p1[i].used = false, _evict(_p1[i].gpv);
}

const class starflow::cache::stats& starflow::cache::stats() const
{
    return _stats;
}

starflow::gpv::ipv4_5tuple starflow::cache::_packet_key(const unsigned char* pkt_buffer_,
    bool includes_eth_)
{
    unsigned offset = (includes_eth_ ? 14 : 0);
    auto ip = om::net::ip4_header(pkt_buffer_ + offset);
    offset += ip.len();
    uint16_t tp_src = 0, tp_dst = 0;

    if (ip.proto() == 6) {
        auto tcp = om::net::tcp_header(pkt_buffer_ + offset);
        tp_src = tcp.src_port(), tp_dst = tcp.dest_port();
    } else if (ip.proto() == 17) {
        auto udp = om::net::udp_header(pkt_buffer_ + offset);
        tp_src = udp.src_port(), tp_dst = udp.dest_port();
    }

    return { ip.src_addr().to_uint32(), ip.dest_addr().to_uint32(), tp_src, tp_dst, ip.proto() };
}

bool starflow::cache::_is_same_gpv(const starflow::gpv_t& gpv_,
    const starflow::gpv::ipv4_5tuple& ipv4_5tuple_)
{
    return gpv_.hdr.ip_src   == ipv4_5tuple_.ip_src
        && gpv_.hdr.ip_dst   == ipv4_5tuple_.ip_dst
        && gpv_.hdr.tp_src   == ipv4_5tuple_.tp_src
        && gpv_.hdr.tp_dst   == ipv4_5tuple_.tp_dst
        && gpv_.hdr.ip_proto == ipv4_5tuple_.ip_proto;
}

void starflow::cache::_set_gpv_hdr(starflow::gpv_t& gpv_, const starflow::gpv::ipv4_5tuple& ipv4_5tuple_,
    unsigned long timestamp_us_)
{
    gpv_.hdr.ip_src    = ipv4_5tuple_.ip_src;
    gpv_.hdr.ip_dst    = ipv4_5tuple_.ip_dst;
    gpv_.hdr.tp_src    = ipv4_5tuple_.tp_src;
    gpv_.hdr.tp_dst    = ipv4_5tuple_.tp_dst;
    gpv_.hdr.ip_proto  = ipv4_5tuple_.ip_proto;
    gpv_.hdr.pkt_count = 1;
    gpv_.hdr.ts_us     = timestamp_us_;
}

void starflow::cache::_evict(gpv_t gpv_)
{
    if (_collect_stats) {
        _stats._pkt_count += gpv_.hdr.pkt_count;
        _stats._gpv_count += 1;
    }

    _gpv_handler(gpv_);
}
