
#ifdef WITH_NETMAP

#include "../include/starflow/gpv_netmap_receiver.h"

starflow::gpv_netmap_receiver::gpv_netmap_receiver(const std::string& iface_name_,
    gpv_handler_t&& gpv_handler_)
    : _iface(iface_name_),
      _poll(_iface.fd(), [this](int fd_, om::async::poll::event event_) { _receive(); }),
      _gpv_handler(std::move(gpv_handler_))
{ }

void starflow::gpv_netmap_receiver::operator()()
{
    _poll.block();
}

void starflow::gpv_netmap_receiver::_receive()
{
    unsigned len = 0;

    for (unsigned rx_ring_id = 0; rx_ring_id < _iface.rx_rings.count(); rx_ring_id++) {
        while (_iface.rx_rings[rx_ring_id].avail()) {
            auto buf = _iface.rx_rings[rx_ring_id].next_buf(len);
            _gpv_handler((starflow::gpv_t*) (buf + 14 + 20 + 8));
            _iface.rx_rings[rx_ring_id].advance();
        }
    }
    _iface.rx_rings.synchronize();
}

#endif
