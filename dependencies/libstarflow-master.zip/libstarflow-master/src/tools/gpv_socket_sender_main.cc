
#include <cxxopts/cxxopts.h>

#include <starflow/cache.h>
#include <starflow/gpv.h>
#include <starflow/gpv_socket_sender.h>
#include <starflow/gpv_file_reader.h>

namespace gpv_sender {

    struct config
    {
        std::string destination;
        std::string input_file_name;
    };

    void _print_help(cxxopts::Options& opts_, int exit_code_ = 0)
    {
        std::ostream& os = (exit_code_ ? std::cerr : std::cout);
        os << opts_.help({""}) << std::endl;
        exit(exit_code_);
    }

    cxxopts::Options _set_options()
    {
        cxxopts::Options opts("gpv_socket_sender", " - ");

        opts.add_options()
                ("i,file", "input file [required]", cxxopts::value<std::string>(), "FILE")
                ("d,destination", "destination host:port]", cxxopts::value<std::string>(), "DEST")
                ("h,help", "print this help message");

        return opts;
    }

    config _parse_config(cxxopts::Options opts_, int argc_, char** argv_)
    {
        config config{};
        auto parsed_opts = opts_.parse(argc_, argv_);

        if (parsed_opts.count("h"))
            _print_help(opts_);

        if (parsed_opts.count("d"))
            config.destination = parsed_opts["d"].as<std::string>();
        else
            _print_help(opts_);

        if (parsed_opts.count("i"))
            config.input_file_name = parsed_opts["i"].as<std::string>();
        else
            _print_help(opts_);

        return config;
    }
}

int main(int argc_, char** argv_)
{
    namespace sf = starflow;
    auto config = gpv_sender::_parse_config(gpv_sender::_set_options(), argc_, argv_);

    sf::gpv_t gpv;
    sf::gpv_file_reader reader(config.input_file_name);
    sf::gpv_socket_sender sender(config.destination);

    while (reader.next(gpv)) sender.send(gpv);

    return 0;
}
