#include <iostream>
#include <iomanip>

#include <cxxopts/cxxopts.h>
#include <starflow/gpv.h>
#include <starflow/gpv_file_reader.h>

namespace gpv_file_print {

	struct config
	{
		std::string input_file_name;
		bool per_packet = false;
		unsigned long limit = 0;
	};

	void _print_help(cxxopts::Options& opts_, int exit_code_ = 0)
	{
		std::ostream& os = (exit_code_ ? std::cerr : std::cout);
		os << opts_.help({""}) << std::endl;
		exit(exit_code_);
	}

	cxxopts::Options _set_options()
	{
		cxxopts::Options opts("gpv_file_print", " - ");

		opts.add_options()
			("i,input", "input file [required]", cxxopts::value<std::string>(), "FILE")
			("p,per-packet", "display per-packet infos")
			("l,limit", "stop after L GPVs", cxxopts::value<unsigned long>(), "L")
			("h,help", "print this help message");

		return opts;
	}

	config _parse_config(cxxopts::Options opts_, int argc_, char** argv_)
	{
		config config{};
		auto parsed_opts = opts_.parse(argc_, argv_);

		if (parsed_opts.count("h"))
			_print_help(opts_);

		if (parsed_opts.count("i"))
			config.input_file_name = parsed_opts["i"].as<std::string>();
		else
			_print_help(opts_);

		config.per_packet = parsed_opts.count("p");

		if (parsed_opts.count("l"))
			config.limit = parsed_opts["l"].as<unsigned long>();

		return config;
	}
}

int main(int argc_, char** argv_)
{
	namespace sf = starflow;
	auto config = gpv_file_print::_parse_config(gpv_file_print::_set_options(), argc_, argv_);

	sf::gpv_file_reader reader(config.input_file_name);

	sf::gpv_t gpv;
	unsigned long long gpv_count = 0;

	while (reader.next(gpv)) {

		std::cout << gpv << std::endl;

		if (config.per_packet) {
			for (auto i = 0; i < gpv.hdr.pkt_count; i++)
				std::cout << "  " << gpv.pkt[i] << std::endl;
		}

		if (config.limit && ++gpv_count > config.limit)
			break;
	}

	return 0;
}