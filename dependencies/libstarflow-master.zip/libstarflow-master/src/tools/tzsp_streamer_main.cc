
#include <iomanip>

#include <cxxopts/cxxopts.h>
#include <om/om.h>
#include <starflow/cache.h>
#include <starflow/gpv.h>
#include <starflow/tzsp_receiver.h>
#include <starflow/gpv_socket_sender.h>


namespace tzsp_streamer {

    struct config
    {
        std::string listen_addr;
        std::string destination_addr;
    };

    void _print_help(cxxopts::Options &opts_, int exit_code_ = 0)
    {
        std::ostream &os = (exit_code_ ? std::cerr : std::cout);
        os << opts_.help({""}) << std::endl;
        exit(exit_code_);
    }

    cxxopts::Options _set_options()
    {
        cxxopts::Options opts("tzsp_streamer", " - ");

        opts.add_options()
                ("l,listen-address", "listen host:port", cxxopts::value<std::string>(), "LISTEN")
                ("d,destination-address", "destination host:port", cxxopts::value<std::string>(),
                 "DEST")
                ("h,help", "print this help message");

        return opts;
    }

    config _parse_config(cxxopts::Options opts_, int argc_, char** argv_)
    {
        config config{};
        auto parsed_opts = opts_.parse(argc_, argv_);

        if (parsed_opts.count("l"))
            config.listen_addr = parsed_opts["l"].as<std::string>();
        else
            _print_help(opts_);

        if (parsed_opts.count("d"))
            config.destination_addr = parsed_opts["d"].as<std::string>();
        else
            _print_help(opts_);

        if (parsed_opts.count("h"))
            _print_help(opts_);

        return config;
    }
}

int main(int argc_, char** argv_)
{
    namespace sf = starflow;
    auto config = tzsp_streamer::_parse_config(tzsp_streamer::_set_options(), argc_, argv_);

    sf::tzsp_receiver receiver(config.listen_addr);
    sf::gpv_socket_sender sender(config.destination_addr);
    sf::cache cache(64, 16, 0, 0, 1, [&sender](sf::gpv_t gpv_) {
        sender.send(gpv_);
    });

    receiver([&cache](const unsigned char* buf_, std::size_t len_) {
        cache.add_packet(buf_, om::etc::now_since_epoch<std::chrono::microseconds>(), true);
    });

    return 0;
}