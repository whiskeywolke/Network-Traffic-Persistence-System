
#include <iomanip>

#include <cxxopts/cxxopts.h>

#include <starflow/cache.h>
#include <starflow/gpv.h>
#include <starflow/gpv_file_writer.h>
#include <starflow/pcap_reader.h>

namespace pcap_gpv_converter {

    struct config
    {
        std::string input_file_name;
        std::string output_file_name;
        unsigned p1_height = 8096;
        unsigned p1_width  = 4;
        unsigned p2_height = 64;
        unsigned p2_width  = 16;
        unsigned verbosity = 0;
        bool includes_ethernet = false;
    };

    std::pair<unsigned, unsigned> _parse_cache_dimensions(const std::string& cache_dimensions_)
    {
        std::size_t comma_pos = cache_dimensions_.find(',');

        if (comma_pos != std::string::npos) {
            std::string width = cache_dimensions_.substr(0, comma_pos);
            std::string height = cache_dimensions_.substr(comma_pos + 1);
            return std::make_pair((unsigned) std::stoul(width), (unsigned) std::stoul(height));
        }

        throw std::invalid_argument("parse_cache_dimensions: invalid argument");
    }

    void _print_help(cxxopts::Options& opts_, int exit_code_ = 0)
    {
        std::ostream& os = (exit_code_ ? std::cerr : std::cout);
        os << opts_.help({""}) << std::endl;
        exit(exit_code_);
    }

    cxxopts::Options _set_options()
    {
        cxxopts::Options opts("pcap_gpv_converter",
            "converts a .pcap packet capture to a file of grouped packet vectors");

        opts.add_options()
            ("i,input", "input file [required]", cxxopts::value<std::string>(), "FILE.pcap")
            ("o,output", "output file [required]", cxxopts::value<std::string>(), "FILE.gpv")
            ("p,primary", "primary cache dimensions", cxxopts::value<std::string>(), "H,W")
            ("s,secondary", "secondary cache dimensions", cxxopts::value<std::string>(), "H,W")
            ("e,ethernet", "pcap includes ethernet header")
            ("v,verbose", "verbosity level")
            ("h,help", "print this help message");

        return opts;
    }

    config _parse_config(cxxopts::Options opts_, int argc_, char** argv_)
    {
        config config{};
        auto parsed_opts = opts_.parse(argc_, argv_);

        if (parsed_opts.count("h"))
            _print_help(opts_);

        if (parsed_opts.count("i"))
            config.input_file_name = parsed_opts["i"].as<std::string>();
        else
            _print_help(opts_);

        if (parsed_opts.count("o"))
            config.output_file_name = parsed_opts["o"].as<std::string>();
        else
            _print_help(opts_);

        if (parsed_opts.count("p")) {
            auto parse_result = _parse_cache_dimensions(parsed_opts["p"].as<std::string>());
            config.p1_height = parse_result.first;
            config.p1_width  = parse_result.second;
        }

        if (parsed_opts.count("s")) {
            auto parse_result = _parse_cache_dimensions(parsed_opts["s"].as<std::string>());
            config.p2_height = parse_result.first;
            config.p2_width  = parse_result.second;
        }

        config.includes_ethernet = parsed_opts.count("e") > 0;

        config.verbosity = (unsigned) parsed_opts.count("v");

        return config;
    }
}

int main(int argc_, char** argv_) {

    namespace sf = starflow;
    auto config = pcap_gpv_converter::_parse_config(pcap_gpv_converter::_set_options(),argc_,argv_);

    const unsigned char* buf = nullptr;
    unsigned long timestamp_us = 0;
    unsigned frame_len = 0, cap_len = 0;

    if (config.verbosity > 0) {
        std::cout << "primary partition: " << std::endl;
        std::cout << "    height: " << config.p1_height << ", width: " << config.p1_width
            << std::endl;
    }

    auto start = om::etc::now();

    sf::pcap_reader reader(config.input_file_name);
    sf::gpv_file_writer writer(config.output_file_name);

    sf::cache cache(config.p1_height, config.p1_width, config.p2_height, config.p2_width, 1,
            [&writer](sf::gpv_t gpv_) { writer.write(gpv_); }, config.verbosity > 0);

    while (reader.next(&buf, timestamp_us, frame_len, cap_len))
        cache.add_packet(buf, timestamp_us, config.includes_ethernet);

    cache.flush();

    if (config.verbosity > 0) {

        auto duration = om::etc::seconds_since(start);

        std::cout << "#packets:        " << std::setw(10) << cache.stats().pkt_count() << std::endl;

        std::cout << "#gpvs:           " << std::setw(10) << cache.stats().gpv_count() << std::endl;

        std::cout << "mean gpv length: " << std::setw(10) << std::setprecision(4)
                  << cache.stats().mean_gpv_length() << std::endl;

        std::cout << "runtime [s]:     " << std::setw(10) << std::setprecision(4)
                  << duration << std::endl;

        std::cout << "new slot ratio:  " << std::setw(10) << std::fixed << std::setprecision(3)
                  << cache.stats().new_slot_ratio() << std::endl;

        std::cout << "append ratio:    " << std::setw(10) << std::fixed << std::setprecision(3)
                  << cache.stats().append_ratio() << std::endl;

        std::cout << "collision ratio: " << std::setw(10) << std::fixed << std::setprecision(3)
                  << cache.stats().collision_ratio() << std::endl;
    }

    return 0;
}
