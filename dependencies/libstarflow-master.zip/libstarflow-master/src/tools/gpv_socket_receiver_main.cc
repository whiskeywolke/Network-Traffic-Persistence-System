
#include <cxxopts/cxxopts.h>

#include <starflow/gpv.h>
#include <starflow/gpv_socket_receiver.h>

namespace gpv_receiver {

    struct config
    {
        std::string bind;
    };

    void _print_help(cxxopts::Options& opts_, int exit_code_ = 0)
    {
        std::ostream& os = (exit_code_ ? std::cerr : std::cout);
        os << opts_.help({""}) << std::endl;
        exit(exit_code_);
    }

    cxxopts::Options _set_options()
    {
        cxxopts::Options opts("gpv_socket_receiver", " - ");

        opts.add_options()
            ("b,bind", "bind addr host:port]", cxxopts::value<std::string>(), "BIND")
            ("h,help", "print this help message");

        return opts;
    }

    config _parse_config(cxxopts::Options opts_, int argc_, char** argv_)
    {
        config config{};
        auto parsed_opts = opts_.parse(argc_, argv_);

        if (parsed_opts.count("h"))
            _print_help(opts_);

        if (parsed_opts.count("b"))
            config.bind = parsed_opts["b"].as<std::string>();
        else
            _print_help(opts_);

        return config;
    }
}

int main(int argc_, char** argv_)
{
    namespace sf = starflow;
    auto config = gpv_receiver::_parse_config(gpv_receiver::_set_options(), argc_, argv_);

    sf::gpv_socket_receiver(config.bind, [](const sf::gpv_t& gpv_) {
        std::cout << gpv_ << std::endl;
    })();

    return 0;
}
