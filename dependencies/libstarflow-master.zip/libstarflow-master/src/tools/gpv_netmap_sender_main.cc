
#include <cxxopts/cxxopts.h>
#include <iostream>
#include <starflow/cache.h>
#include <starflow/gpv.h>
#include <starflow/gpv_netmap_sender.h>
#include <starflow/gpv_file_reader.h>

namespace gpv_netmap_sender {

    struct config
    {
        std::string file_name;
        std::string interface;
        std::string mac_source;
        std::string ip_port_source;
        std::vector<std::string> mac_destination;
        std::vector<std::string> ip_port_destination;
        bool benchmark = true;
        bool loop = false;
        unsigned verbosity = 0;
    };

    void _print_help(cxxopts::Options& opts_, int exit_code_ = 0)
    {
        std::ostream& os = (exit_code_ ? std::cerr : std::cout);
        os << opts_.help({""}) << std::endl;
        exit(exit_code_);
    }

    cxxopts::Options _set_options()
    {
        cxxopts::Options opts("gpv_netmap_sender", " - ");

        opts.add_options()
            ("f,file", "input file name [required]",
                cxxopts::value<std::string>(), "FILE.gpv")
            ("i,interface", "netmap interface [required]",
                cxxopts::value<std::string>(), "INTERFACE")
            ("S,mac-source", "source MAC address [required]",
                cxxopts::value<std::string>(), "MAC-ADDR")
            ("s,source-addr", "source ip:port [required]",
                cxxopts::value<std::string>(), "IP:PORT")
            ("D,mac-dest", "destination MAC address [required]",
                cxxopts::value<std::string>(), "MAC-ADDR")
            ("d,dest-addr", "destination ip:port [required]",
                cxxopts::value<std::string>(), "IP:PORT")
            ("r,node", "set node id",
                cxxopts::value<unsigned>(), "R")
            ("m,benchmark", "print benchmark output")
            ("l,loop", "loop infinitely over input file")
            ("v,verbose", "verbosity")
            ("h,help", "print this help message");

        return opts;
    }

    config _parse_config(cxxopts::Options opts_, int argc_, char** argv_)
    {
        config config{};
        auto parsed_opts = opts_.parse(argc_, argv_);

        if (parsed_opts.count("h"))
            _print_help(opts_);

        if (parsed_opts.count("f"))
            config.file_name = parsed_opts["f"].as<std::string>();
        else
            _print_help(opts_);

        if (parsed_opts.count("i"))
            config.interface = parsed_opts["i"].as<std::string>();
        else
            _print_help(opts_);

        if (parsed_opts.count("S"))
            config.mac_source = parsed_opts["S"].as<std::string>();
        else
            _print_help(opts_);

        if (parsed_opts.count("s"))
            config.ip_port_source = parsed_opts["s"].as<std::string>();
        else
            _print_help(opts_);

        if (parsed_opts.count("D"))
            config.mac_destination = om::etc::tokenize(parsed_opts["D"].as<std::string>());
        else
            _print_help(opts_);

        if (parsed_opts.count("d")) {
            config.ip_port_destination = om::etc::tokenize(parsed_opts["d"].as<std::string>());
        } else
            _print_help(opts_);

        config.loop = parsed_opts.count("l") > 0;

        config.verbosity = (unsigned) parsed_opts.count("v");

        return config;
    }
}

struct counter {
    unsigned long gpv = 0, pkt = 0;
    bool stop         = false;

    inline void increment(unsigned long gpv_, unsigned long pkt_)
    {
        gpv += gpv_, pkt += pkt_;
    }

    inline void reset()
    {
        gpv = 0, pkt = 0;
    }
};

int main(int argc_, char** argv_)
{
    namespace sf = starflow;
    auto config = gpv_netmap_sender::_parse_config(gpv_netmap_sender::_set_options(), argc_, argv_);

    sf::gpv_t gpv;
    sf::gpv_file_reader reader(config.file_name);
    counter counter;

    if (config.benchmark) {
        std::thread t([&config, &counter]() {
            while (!counter.stop) {
                std::this_thread::sleep_for(std::chrono::seconds(1));
                auto now_ms = om::etc::now_since_epoch<std::chrono::milliseconds>();
                std::cout << config.interface << "," <<  now_ms << "," << counter.gpv
                    << "," << counter.pkt << std::endl;
                counter.reset();
            }
        }); t.detach();
    }

    sf::gpv_netmap_sender sender(config.interface, config.mac_source, config.ip_port_source,
        config.mac_destination, config.ip_port_destination, config.verbosity);

    while (config.loop) {
        while (reader.next(gpv)) {
            sender.send(gpv);
            counter.increment(1, gpv.hdr.pkt_count);
        }
        reader.reset();
    }

    return 0;
}
