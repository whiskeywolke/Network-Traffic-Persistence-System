
#include <iostream>
#include <iomanip>

#include <cxxopts/cxxopts.h>
#include <starflow/gpv.h>
#include <starflow/gpv_file_reader.h>

namespace gpv_file_info {

    struct config
    {
        std::string input_file_name;
    };

    void _print_help(cxxopts::Options& opts_, int exit_code_ = 0)
    {
        std::ostream& os = (exit_code_ ? std::cerr : std::cout);
        os << opts_.help({""}) << std::endl;
        exit(exit_code_);
    }

    cxxopts::Options _set_options()
    {
        cxxopts::Options opts("gpv_file_info", " - ");

        opts.add_options()
            ("i,input", "input file [required]", cxxopts::value<std::string>(), "FILE")
            ("h,help", "print this help message");

        return opts;
    }

    config _parse_config(cxxopts::Options opts_, int argc_, char** argv_)
    {
        config config{};
        auto parsed_opts = opts_.parse(argc_, argv_);

        if (parsed_opts.count("h"))
            _print_help(opts_);

        if (parsed_opts.count("i"))
            config.input_file_name = parsed_opts["i"].as<std::string>();
        else
            _print_help(opts_);

        return config;
    }
}

int main(int argc_, char** argv_)
{
    namespace sf = starflow;
    auto config = gpv_file_info::_parse_config(gpv_file_info::_set_options(), argc_, argv_);

    sf::gpv_file_reader reader(config.input_file_name);

    sf::gpv_t gpv;
    unsigned long long pkt_count = 0, gpv_count = 0;
    starflow::gpv_t first_gpv {}, previous_gpv {};

    while (reader.next(gpv)) {

        if (!gpv_count) { // only first gpv
            first_gpv = gpv;
        }

        gpv_count += 1;
        pkt_count += gpv.hdr.pkt_count;
        previous_gpv = gpv;
    }

    std::time_t first_ts = first_gpv.unix_time_stamp_s();
    std::time_t last_ts  = previous_gpv.unix_time_stamp_s();

    std::cout << "gpv_file_info: " << config.input_file_name << std::endl;
    std::cout << "  total GPVs:        " << gpv_count << std::endl;
    std::cout << "  total packets:     " << pkt_count << std::endl;
    std::cout << "  mean GPV length:   " << std::setprecision(3)
              << pkt_count / (double) gpv_count << std::endl;
    std::cout << "  start:             "
              << std::put_time(std::localtime(&first_ts), "%F %H:%M:%S%z") << std::endl;
    std::cout << "  end:               "
              << std::put_time(std::localtime(&last_ts), "%F %H:%M:%S%z") << std::endl;

    return 0;
}
