
#include <cxxopts/cxxopts.h>
#include <iostream>
#include <starflow/gpv.h>
#include <starflow/gpv_netmap_receiver.h>


namespace gpv_receiver {

    struct config
    {
        std::string bind;
        unsigned verbosity;
    };

    void _print_help(cxxopts::Options& opts_, int exit_code_ = 0)
    {
        std::ostream& os = (exit_code_ ? std::cerr : std::cout);
        os << opts_.help({""}) << std::endl;
        exit(exit_code_);
    }

    cxxopts::Options _set_options()
    {
        cxxopts::Options opts("gpv_netmap_receiver", " - ");

        opts.add_options()
                ("b,bind", "bind to interface", cxxopts::value<std::string>(), "BIND")
                ("v,verbose", "verbosity level")
                ("h,help", "print this help message");

        return opts;
    }

    config _parse_config(cxxopts::Options opts_, int argc_, char** argv_)
    {
        config config{};
        auto parsed_opts = opts_.parse(argc_, argv_);

        if (parsed_opts.count("h"))
            _print_help(opts_);

        if (parsed_opts.count("b"))
            config.bind = parsed_opts["b"].as<std::string>();
        else
            _print_help(opts_);

        config.verbosity = (unsigned) parsed_opts.count("v");

        return config;
    }
}

int main(int argc_, char** argv_)
{
    namespace sf = starflow;
    auto config = gpv_receiver::_parse_config(gpv_receiver::_set_options(), argc_, argv_);

    unsigned long gpv_count = 0;


    sf::gpv_netmap_receiver receiver(config.bind, [&config, &gpv_count](starflow::gpv_t* gpv_) {

        gpv_count++;

        if (config.verbosity > 0) {

            if (gpv_count %  100000 == 0)
                std::cout << gpv_count << std::endl;

            if (config.verbosity > 1)
                std::cout << *gpv_ << std::endl;
        }
    });

    receiver();

    return 0;
}
