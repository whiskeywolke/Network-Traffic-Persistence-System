
#include "../include/starflow/gpv_buffer_reader.h"

starflow::gpv_buffer_reader::gpv_buffer_reader(unsigned char* buffer_, std::size_t len_)
        : _buffer(buffer_), _len(len_), _index(0) { }

bool starflow::gpv_buffer_reader::next(starflow::gpv_t& gpv_)
{
    gpv_ = *((starflow::gpv_t*) (_buffer + _index));
    _index += sizeof(starflow::gpv::hdr)
              + (unsigned) gpv_.hdr.pkt_count * sizeof(starflow::gpv::pkt);
    return (unsigned) gpv_.hdr.pkt_count > 0 && _index < _len;
}
