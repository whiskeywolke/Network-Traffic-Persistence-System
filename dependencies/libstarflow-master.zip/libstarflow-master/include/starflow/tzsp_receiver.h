
#ifndef STARFLOW_TZSP_RECEIVER_H
#define STARFLOW_TZSP_RECEIVER_H

#include <cstdint>
#include <om/om.h>

namespace starflow {

    using namespace std::placeholders;

    class tzsp_receiver
    {
        struct tzsp_header {
            uint8_t  version;
            uint8_t  type;
            uint16_t encap;
        };

        struct tzsp_tag {
            uint8_t type;
            uint8_t length;
            char    data[];
        };

    public:
        using packet_handler_t = std::function<void (const unsigned char*, std::size_t len_)>;
        explicit tzsp_receiver(const std::string& listen_addr_);
        void operator()(packet_handler_t&& packet_handler_);

    private:
        void _poll_event(int fd_, om::async::poll::event ev_);

        om::net::socket _socket;
        om::async::poll _poll;
        packet_handler_t _packet_handler;

        int _rx_len                 = -1;
        unsigned char _rx_buf[2048] = {0};
        unsigned char* _msg_ptr     = nullptr;
        unsigned char* _msg_end     = nullptr;
    };
}

#endif
