
#ifndef STARFLOW_GPV_NETMAP_SENDER_H
#define STARFLOW_GPV_NETMAP_SENDER_H
#ifdef WITH_NETMAP

#include "gpv.h"
#include "load_balancer.h"

#include <string>
#include <om/om.h>
#include <netmap_tools/netmap_tools.h>

namespace starflow {
    class gpv_netmap_sender
    {
    public:

        explicit gpv_netmap_sender(const std::string& iface_name_, const std::string& mac_src_,
            const std::string& ip_port_src_, const std::vector<std::string>& mac_dst_,
            const std::vector<std::string>& ip_port_dst_, unsigned verbosity_ = 0);

        explicit gpv_netmap_sender(const std::string& iface_name_, const std::string& mac_src_,
            const std::string& ip_port_src_, const std::string& mac_dst_,
            const std::string& ip_port_dst_, unsigned verbosity_ = 0);

        void send(const gpv_t& gpv_);

    private:
        netmap::iface _iface;
        unsigned _current_ring = 0;
        unsigned char _header_buffer[64] = {0};
        om::net::ethernet_header _ether;
        om::net::ip4_header _ip;
        om::net::udp_header _udp;
        starflow::load_balancer<starflow::gpv::ipv4_5tuple> _load_balancer;
        unsigned long _packet_count = 0;
        unsigned _verbosity = 0;

        unsigned _next_ring();
    };
}

#endif
#endif
