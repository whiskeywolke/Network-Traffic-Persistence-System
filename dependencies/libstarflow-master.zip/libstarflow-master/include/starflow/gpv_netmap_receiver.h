
#ifndef STARFLOW_GPV_NETMAP_RECEIVER_H
#define STARFLOW_GPV_NETMAP_RECEIVER_H
#ifdef WITH_NETMAP

#include "gpv.h"

#include <string>
#include <om/om.h>
#include <netmap_tools/netmap_tools.h>

namespace starflow {
    class gpv_netmap_receiver {
    public:
        using gpv_handler_t = std::function<void (gpv_t* gpv_)>;
        explicit gpv_netmap_receiver(const std::string &iface_name_, gpv_handler_t&& gpv_handler_);
        void operator()();
    private:
        netmap::iface _iface;
        om::async::poll _poll;
        gpv_handler_t _gpv_handler;

        void _receive();
    };
}

#endif
#endif
