
#ifndef STARFLOW_BUFFER_READER_H
#define STARFLOW_BUFFER_READER_H

#include "gpv.h"

#include <cstdint>

namespace starflow {
    class gpv_buffer_reader
    {
    public:
        gpv_buffer_reader()                                = delete;
        gpv_buffer_reader(const gpv_buffer_reader&)            = delete;
        gpv_buffer_reader& operator=(const gpv_buffer_reader&) = delete;
        explicit gpv_buffer_reader(unsigned char* buffer_, std::size_t len_);
        bool next(starflow::gpv_t& gpv_);
        inline void reset() { _index = 0; }
    private:
        unsigned char* _buffer;
        std::size_t _len, _index;
    };
}

#endif
