
#ifndef STARFLOW_GPV_RECEIVER_H
#define STARFLOW_GPV_RECEIVER_H

#include <om/om.h>

#include "gpv.h"

namespace starflow {

    using namespace std::placeholders;

    class gpv_socket_receiver
    {
    public:
        using gpv_handler_t = std::function<void (gpv_t)>;
        explicit gpv_socket_receiver(const std::string& addr_, gpv_handler_t&& gpv_handler_);
        void operator()();

    private:
        void _poll_event(int fd_, om::async::poll::event ev_);

        gpv_handler_t   _gpv_handler;
        om::net::socket _socket;
        om::async::poll _poll;

        int _rx_len                 = -1;
        unsigned char _rx_buf[2048] = {0};
    };
}

#endif
