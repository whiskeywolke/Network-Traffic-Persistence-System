
#ifndef STARFLOW_GPV_FILE_READER_H
#define STARFLOW_GPV_FILE_READER_H

#include <om/om.h>
#include "gpv.h"

namespace starflow {
    class gpv_file_reader : public om::file::_file_stream
    {
    public:
        explicit gpv_file_reader(const std::string& file_name_, bool use_buffer_ = false);
        bool next(gpv_t& gpv_);
        void reset();
        bool done();
        ~gpv_file_reader() override = default;

    private:
        void _read_gpv(gpv_t& gpv_);

        bool _use_buffer;
        std::vector<gpv_t> _data;
        typename std::vector<gpv_t>::const_iterator _iter;
    };
}

#endif
