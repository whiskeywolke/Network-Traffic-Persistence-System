
#ifndef STARFLOW_LOAD_BALANCER_H
#define STARFLOW_LOAD_BALANCER_H

#include <cstdint>
#include <vector>
#include <stdexcept>
#include <om/om.h>

namespace starflow {
	template <typename K>
	class load_balancer
	{
	public:
		struct destination {

			om::net::ip4_addr ip;
			uint16_t  port;
			om::net::mac_addr mac;
		};

		struct destination destination(const K& key_)
		{
			if (_destinations.size() == 0)
				throw std::logic_error("starflow::load_balancer: no destinations configured");
			else if (_destinations.size() == 1) {
				return _destinations[0];
			}

			return _destinations[std::hash<K>()(key_) % _destinations.size()];
		}

		void add_destination(om::net::ip4_addr ip_, uint16_t port_,
				om::net::mac_addr mac_ = om::net::mac_addr())
		{
			_destinations.push_back({ip_, port_, mac_});
		}

	private:
		std::vector<struct destination> _destinations;
	};
}

#endif
