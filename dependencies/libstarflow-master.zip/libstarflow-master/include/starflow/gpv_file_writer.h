
#ifndef STARFLOW_GPV_FILE_WRITER_H
#define STARFLOW_GPV_FILE_WRITER_H

#include <om/om.h>
#include "gpv.h"

namespace starflow {
    class gpv_file_writer : public om::file::_file_stream
    {
    public:
        explicit gpv_file_writer(const std::string& file_name_);

        //! writes gpv_ to the file
        std::size_t write(const gpv_t& gpv_);
    };
}

#endif
