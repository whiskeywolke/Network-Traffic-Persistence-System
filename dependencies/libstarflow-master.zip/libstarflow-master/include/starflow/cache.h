
#ifndef STARFLOW_CACHE_H
#define STARFLOW_CACHE_H

#include "gpv.h"

#include <cstdlib>
#include <functional>
#include <memory>
#include <om/om.h>

namespace starflow {
    class cache {

        struct cache_slot {
            bool used = false;
            gpv_t gpv = {{}, {}};
        };

    public:

        class stats
        {
            friend class cache;
        public:
            unsigned long long pkt_count() const;
            unsigned long long gpv_count() const;
            unsigned long long new_slot_count() const;
            unsigned long long append_count() const;
            unsigned long long collision_count() const;

            double new_slot_ratio() const;
            double append_ratio() const;
            double collision_ratio() const;

            double mean_gpv_length() const;
        private:
            unsigned long long _pkt_count       = 0;
            unsigned long long _gpv_count       = 0;
            unsigned long long _new_slot_count  = 0;
            unsigned long long _append_count    = 0;
            unsigned long long _collision_count = 0;
        };

        using gpv_handler_t = std::function<void (starflow::gpv_t)>;

        explicit cache(std::size_t p1_height_, std::size_t p1_width_, std::size_t p2_height_,
                std::size_t p2_width_, std::size_t associativity, gpv_handler_t&& gpv_handler_,
                bool collect_stats_ = false);

        void add_packet(const unsigned char* pkt_buffer_, unsigned long timestamp_us_,
                        bool includes_eth_ = false);

        void flush();

        const stats& stats() const;

    private:
        gpv::ipv4_5tuple _packet_key(const unsigned char* pkt_buffer_, bool includes_eth_ = false);

        bool _is_same_gpv(const gpv_t& gpv_, const gpv::ipv4_5tuple& ipv4_5tuple_);

        void _set_gpv_hdr(gpv_t& gpv_, const gpv::ipv4_5tuple& ipv4_5tuple_,
            unsigned long timestamp_us_);

        void _evict(gpv_t gpv_);

        std::size_t _p1_height;
        std::size_t _p1_width;
        std::size_t _p2_height;
        std::size_t _p2_width;
        std::size_t _associativity;
        gpv_handler_t _gpv_handler;

        bool _collect_stats;
        class stats _stats;

        std::unique_ptr<cache_slot[]> _p1;
        unsigned _seed;
    };
}

#endif
