
#ifndef STARFLOW_GPV_SENDER_H
#define STARFLOW_GPV_SENDER_H

#include "gpv.h"

#include <string>
#include <om/om.h>

namespace starflow {
    class gpv_socket_sender
    {
    public:
        explicit gpv_socket_sender(const std::string& dest_);
        void send(const gpv_t& gpv_);

    private:
        om::net::socket _socket;
        std::string _ip_dst;
        unsigned short _udp_dst;
    };
}

#endif
