## libstarflow

![](https://github.com/jsonch/libstarflow/workflows/ci/badge.svg)

Software Implementation of the *Flow Network Telemetry System[^1]

### Build

#### Requirements

* libpcap

#### Build using CMake

libstarflow uses the cmake build system. Use this command to compile the library,
applications and unit tests in a directory called `build`:


    mkdir build
    cd build
    cmake ..
    make
    
### Unit Tests

Run the unit tests:

    make -C build test
    
### Tools/Examples

#### pcap_gpv_converter

Converts a .pcap packet capture to a grouped packet vectors and writes the resulting gpvs in binary
format to a file.

Example:

    ./pcap_gpv_converter -i caida2015_02_dirA.pcap -o caida15_2a.gpv -p 8096,6 -s 128,16 -v
    
#### gpv_socket_sender

Reads GPVs from a .gpv file and sends the GPVs over a UDP socket to a specified destination.

Example:

    ./gpv_socket_sender -i caida15_2a.gpv -d 127.0.0.1:42002
    
    
#### gpv_socket_receiver

Receives GPVs over the network and prints information on received GPVs.

Example:

    ./gpv_socket_receiver -b 0.0.0.0:42002
    

#### tzsp_streamer

Receives packet records from a TZSP[^2] compatible device, generates GPVs and sends them to
a destination.

Example:

    ./tzsp_streamer -l 0.0.0.0:37008 -d 127.0.0.1:38000
    
    
#### netmap_info

(if compiled with -DWITH_NETMAP=1)

Prints information about a netmap-compatible network adapter.

Example:

    ./netmap_info enp2s0f0
    
    
#### gpv_netmap_receiver

(if compiled with -DWITH_NETMAP=1)

Receives GPV data from a netmap-compatible network adapter and prints received GPVs.    

Example:

    ./gpv_netmap_receiver -b enp2s0f1
    

#### gpv_netmap_sender

(if compuiled with -DWITH_NETMAP=1)

Sends GPV data from a file over a netmap-compatible network adapter.

Example:

    ./gpv_netmap_sender -f /mnt/raid/caida-traces/caida15_2a.gpv -i enp2s0f0 \
        -S 68:05:ca:39:84:94 -s 192.168.15.1:37000 \
        -D 68:05:ca:39:84:95 -d 192.168.15.2:37001 -l


[^1]: https://www.usenix.org/conference/atc18/presentation/sonchack
[^2]: https://en.wikipedia.org/wiki/TZSP
