#include <catch.h>
#include <starflow/util.h>
#include <starflow/gpv.h>

TEST_CASE("hash", "[hash]")
{
    const uint32_t seed = 0x12db5e3a;

    starflow::gpv::hdr hdr1;
    hdr1.ip_src = 1;
    hdr1.ip_dst = 2;
    hdr1.ip_proto = 3;
    hdr1.tp_dst = 1;
    hdr1.tp_src = 1;
    hdr1.pkt_count = 12;

    starflow::gpv::hdr hdr2;
    hdr2.ip_src = 1;
    hdr2.ip_dst = 2;
    hdr2.ip_proto = 3;
    hdr2.tp_dst = 1;
    hdr2.tp_src = 1;
    hdr2.pkt_count = 8;

    // reverse of hdr2
    starflow::gpv::hdr hdr3;
    hdr3.ip_src = 2;
    hdr3.ip_dst = 1;
    hdr3.ip_proto = 3;
    hdr3.tp_src = 1;
    hdr3.tp_dst = 1;

    auto hash1 = starflow::util::hash::murmur3(&hdr1, 13, seed);
    auto hash2 = starflow::util::hash::murmur3(&hdr2, 13, seed);
    auto hash3 = starflow::util::hash::murmur3(&hdr3, 13, seed);

    CHECK(hash1.h1 == hash2.h1);
    CHECK(hash1.h2 == hash2.h2);

    // check hash of reverse flow is different
    CHECK(hash3.h1 != hash2.h1);
    CHECK(hash3.h2 != hash2.h2);

    CHECK(std::hash<starflow::gpv::hdr>()(hdr1) == std::hash<starflow::gpv::hdr>()(hdr2));
}
