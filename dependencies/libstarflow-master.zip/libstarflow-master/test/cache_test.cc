
#include <catch.h>
#include <starflow/cache.h>
#include <iostream>

#include "packet_bytes.h"

TEST_CASE("cache", "[cache]")
{
    unsigned gpv_counter = 0;
    starflow::cache cache(1024, 2, 32, 16, 1, [&gpv_counter](starflow::gpv_t gpv_) {
        gpv_counter++;
    }, false);

    CHECK_NOTHROW(cache.add_packet(pkt1, 123));
    CHECK_NOTHROW(cache.add_packet(pkt2, 124));
    CHECK_NOTHROW(cache.add_packet(pkt3, 125));
    CHECK_NOTHROW(cache.add_packet(pkt4, 126));
    CHECK_NOTHROW(cache.add_packet(pkt5, 127));
    CHECK_NOTHROW(cache.add_packet(pkt6, 128));
    CHECK_NOTHROW(cache.add_packet(pkt7, 129));
    CHECK_NOTHROW(cache.add_packet(pkt8, 130));
    CHECK(gpv_counter == 2);

    CHECK_NOTHROW(cache.flush());
    CHECK(gpv_counter == 6);
}
