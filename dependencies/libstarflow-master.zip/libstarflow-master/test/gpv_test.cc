
#include <catch.h>
#include <starflow/gpv.h>
#include <starflow/gpv_file_reader.h>
#include <starflow/gpv_file_writer.h>

TEST_CASE("gpv", "[gpv]")
{
    starflow::gpv_t gpv1;
    gpv1.hdr.ip_proto = 6, gpv1.hdr.ip_src = 2, gpv1.hdr.ip_dst = 3, gpv1.hdr.tp_src = 12,
            gpv1.hdr.tp_dst = 13,
            gpv1.hdr.ts_us = 1549757791000000, gpv1.hdr.pkt_count = 5,
            gpv1.pkt[0].pkt_len = 40, gpv1.pkt[1].pkt_len = 80, gpv1.pkt[2].pkt_len = 12,
            gpv1.pkt[3].pkt_len = 14, gpv1.pkt[4].pkt_len = 90,
            gpv1.pkt[0].ts_delta_us = 121, gpv1.pkt[1].ts_delta_us = 302,
            gpv1.pkt[2].ts_delta_us = 308, gpv1.pkt[3].ts_delta_us = 350,
            gpv1.pkt[4].ts_delta_us = 1021;

    starflow::gpv_t gpv2;
    gpv2.hdr.ip_proto = 17, gpv2.hdr.ip_src = 9, gpv2.hdr.ip_dst = 12, gpv2.hdr.tp_src = 12,
            gpv2.hdr.tp_dst = 13,
            gpv2.hdr.ts_us = 1549757791500000, gpv2.hdr.pkt_count = 3,
            gpv2.pkt[0].pkt_len = 42, gpv2.pkt[1].pkt_len = 54, gpv2.pkt[2].pkt_len = 89,
            gpv2.pkt[0].ts_delta_us = 80, gpv2.pkt[1].ts_delta_us = 1250,
            gpv2.pkt[2].ts_delta_us = 1900;


    SECTION("total_bytes()") {
        CHECK(gpv1.total_bytes() == 236);
        CHECK(gpv2.total_bytes() == 185);
    }

    SECTION("unix_time_stamp_s()")
    {
        CHECK(gpv1.unix_time_stamp_s() == 1549757791);
        CHECK(gpv2.unix_time_stamp_s() == 1549757791);
    }


    SECTION("unix_time_stamp_ms()")
    {
        CHECK(gpv1.unix_time_stamp_ms() == 1549757791000);
        CHECK(gpv2.unix_time_stamp_ms() == 1549757791500);
    }

    SECTION("std::hash<>")
    {
        CHECK(std::hash<starflow::gpv_t>()(gpv1)        == 0x832a37877c);
        CHECK(std::hash<starflow::gpv::hdr>()(gpv1.hdr) == 0x832a37877c);
        CHECK(std::hash<starflow::gpv_t>()(gpv2)        == 0x24bea3789c1);
        CHECK(std::hash<starflow::gpv::hdr>()(gpv2.hdr) == 0x24bea3789c1);
    }
}

TEST_CASE("gpv::ip4_5tuple", "[gpv]")
{
    starflow::gpv_t gpv1;
    gpv1.hdr.ip_proto = 6, gpv1.hdr.ip_src = 2, gpv1.hdr.ip_dst = 3, gpv1.hdr.tp_src = 12,
    gpv1.hdr.tp_dst = 13;

    starflow::gpv::ipv4_5tuple a;
    a.ip_src   = 2389892;
    a.ip_dst   = 6769222;
    a.tp_src   = 80;
    a.tp_dst   = 28392;
    a.ip_proto = 6;

    auto b = a;
    auto c = a;
    c.ip_proto = 16;


    SECTION("from_gpv")
    {
        auto i5t = starflow::gpv::ipv4_5tuple::from_gpv(gpv1);
        CHECK(i5t.ip_proto == 6);
        CHECK(i5t.ip_dst == 3);
        CHECK(i5t.ip_src == 2);
        CHECK(i5t.tp_src == 12);
        CHECK(i5t.tp_dst == 13);
    }

    SECTION("std::hash<>")
    {
        CHECK(std::hash<starflow::gpv::ipv4_5tuple>()(a) == 0x902896608f58f96);
    }

    SECTION("operator==")
    {
        CHECK(a == b);
        CHECK_FALSE(a == c);
        CHECK_FALSE(b == c);
    }
}

TEST_CASE("gpv::file_writer/gpv::file_reader", "[gpv]")
{
    starflow::gpv_t gpv1;
    gpv1.hdr.ip_proto = 6, gpv1.hdr.ip_src = 2, gpv1.hdr.ip_dst = 3, gpv1.hdr.tp_src = 12,
    gpv1.hdr.tp_dst = 13,
    gpv1.hdr.ts_us = 2133941000000, gpv1.hdr.pkt_count = 5,
    gpv1.pkt[0].pkt_len = 40, gpv1.pkt[1].pkt_len = 80, gpv1.pkt[2].pkt_len = 12,
    gpv1.pkt[3].pkt_len = 14, gpv1.pkt[4].pkt_len = 90,
    gpv1.pkt[0].ts_delta_us = 121, gpv1.pkt[1].ts_delta_us = 302,
    gpv1.pkt[2].ts_delta_us = 308, gpv1.pkt[3].ts_delta_us = 350,
    gpv1.pkt[4].ts_delta_us = 1021;

    starflow::gpv_t gpv2;
    gpv2.hdr.ip_proto = 17, gpv2.hdr.ip_src = 9, gpv2.hdr.ip_dst = 12, gpv2.hdr.tp_src = 12,
    gpv2.hdr.tp_dst = 13,
    gpv2.hdr.ts_us = 2133941500000, gpv2.hdr.pkt_count = 3,
    gpv2.pkt[0].pkt_len = 42, gpv2.pkt[1].pkt_len = 54, gpv2.pkt[2].pkt_len = 89,
    gpv2.pkt[0].ts_delta_us = 80, gpv2.pkt[1].ts_delta_us = 1250,
    gpv2.pkt[2].ts_delta_us = 1900;

    SECTION("write a gpv file")
    {
        starflow::gpv_file_writer writer("test/test.gpv");
        CHECK(writer.write(gpv1) == 104);
        CHECK(writer.write(gpv2) == 72);
        writer.close();
    }

    SECTION("read a gpv file")
    {
        starflow::gpv_t gpv;
        starflow::gpv_file_reader reader("test/test.gpv");
        CHECK(reader.next(gpv));
        CHECK(gpv.hdr.ip_proto == 6);
        CHECK(gpv.hdr.pkt_count == 5);
        CHECK(gpv.pkt[0].pkt_len == 40);
        CHECK(gpv.pkt[4].pkt_len == 90);
        CHECK(gpv.pkt[5].pkt_len == 0);
        CHECK(reader.next(gpv));
        CHECK(gpv.hdr.ip_proto == 17);
        CHECK(gpv.hdr.pkt_count == 3);
        CHECK(gpv.pkt[0].pkt_len == 42);
        CHECK(gpv.pkt[2].pkt_len == 89);
        CHECK(gpv.pkt[4].pkt_len == 0);
        CHECK_FALSE(reader.next(gpv));
        CHECK(reader.done());
        reader.close();
    }
}
