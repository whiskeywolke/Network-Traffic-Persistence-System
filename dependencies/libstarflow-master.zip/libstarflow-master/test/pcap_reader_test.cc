#include <catch.h>
#include <starflow/pcap_reader.h>

TEST_CASE("pcap_reader", "[pcap_reader]")
{
    SECTION("pcap_reader")
    {
        starflow::pcap_reader reader("test/test.pcap");
        CHECK(reader.is_open());
        CHECK_FALSE(reader.done());
    }

    SECTION("file_name")
    {
        starflow::pcap_reader reader("test/test.pcap");
        CHECK(reader.file_name() == "test/test.pcap");
    }

    SECTION("next")
    {
        const unsigned char* buf = nullptr;
        unsigned long timestamp_us = 0;
        unsigned frame_len = 0, cap_len = 0;

        starflow::pcap_reader reader("test/test.pcap");
        CHECK(reader.is_open());
        CHECK_FALSE(reader.done());
        CHECK(reader.next(&buf, timestamp_us, frame_len, cap_len));
        CHECK(frame_len == 1504);
        CHECK(cap_len == 52);
        CHECK(timestamp_us == 1424350751587539);
        CHECK(buf[0] == 0x45);
        CHECK(buf[8] == 0x3c);
        CHECK_FALSE(reader.done());
        CHECK(reader.next(&buf, timestamp_us, frame_len, cap_len));
        CHECK(cap_len == 52);
        CHECK(frame_len == 1454);
        CHECK(timestamp_us == 1424350751587540);
        CHECK_FALSE(reader.done());
        CHECK(reader.next(&buf, timestamp_us, frame_len, cap_len));
        CHECK(cap_len == 64);
        CHECK_FALSE(reader.done());
        CHECK(reader.next(&buf, timestamp_us, frame_len, cap_len));
        CHECK(cap_len == 52);
        CHECK_FALSE(reader.done());
        CHECK(reader.next(&buf, timestamp_us, frame_len, cap_len));
        CHECK(cap_len == 52);
        CHECK(buf[22] == 0xce);
        CHECK(buf[33] == 0x10);
        CHECK_FALSE(reader.done());
        CHECK_FALSE(reader.next(&buf, timestamp_us, frame_len, cap_len));
        CHECK(reader.done());
        reader.close();
    }

    SECTION("close")
    {
        starflow::pcap_reader reader("test/test.pcap");
        CHECK(reader.is_open());
        reader.close();
        CHECK_FALSE(reader.is_open());
    }
}
