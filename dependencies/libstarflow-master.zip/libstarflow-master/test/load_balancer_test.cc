
#include <catch.h>

#include <starflow/load_balancer.h>

TEST_CASE("load_balancer", "[load_balander]")
{
	starflow::load_balancer<int> balancer;

	CHECK_THROWS(balancer.destination(231));

	balancer.add_destination(om::net::ip4_addr::from_string("1.2.3.4"), 12329, om::net::mac_addr());

	CHECK(balancer.destination(12).ip == om::net::ip4_addr::from_string("1.2.3.4"));
	CHECK(balancer.destination(34).ip == om::net::ip4_addr::from_string("1.2.3.4"));

	balancer.add_destination(om::net::ip4_addr::from_string("1.2.3.5"), 12330);

	CHECK(balancer.destination(12).ip == om::net::ip4_addr::from_string("1.2.3.4"));
	CHECK(balancer.destination(12321).ip == om::net::ip4_addr::from_string("1.2.3.5"));
	CHECK(balancer.destination(12).ip == om::net::ip4_addr::from_string("1.2.3.4"));
	CHECK(balancer.destination(12321).ip == om::net::ip4_addr::from_string("1.2.3.5"));
}